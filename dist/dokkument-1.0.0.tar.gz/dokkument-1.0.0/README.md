# dokkument

**Gestore CLI per documentazione aziendale tramite file .dokk**

![Python](https://img.shields.io/badge/python-3.8%2B-blue)
![License](https://img.shields.io/badge/license-MIT-green)
![Version](https://img.shields.io/badge/version-1.0.0-red)

`dokkument` è un'applicazione a riga di comando che consente di gestire e accedere rapidamente alla documentazione aziendale utilizzando file `.dokk` contenenti link organizzati. Perfetto per team di sviluppo, sysadmin e aziende che necessitano di un accesso rapido a risorse documentali distribuite.

## 🚀 Caratteristiche

- **🔍 Scansione automatica** di file `.dokk` nella directory corrente e sottodirectory
- **🎨 Interfaccia colorata** con supporto per link cliccabili nei terminali compatibili
- **🌍 Apertura browser** intelligente multipiattaforma (Windows, macOS, Linux)
- **⚙️ Configurazione flessibile** con file JSON personalizzabili
- **📤 Esportazione** in multipli formati (testo, Markdown, HTML, JSON)
- **✅ Validazione URL** per garantire la correttezza dei link
- **🔧 Zero dipendenze** esterne obbligatorie - usa solo librerie standard Python

## 📦 Installazione

### Installazione rapida

```bash
pip install dokkument
```

### Installazione da sorgente

```bash
git clone https://github.com/your-username/dokkument.git
cd dokkument
pip install -e .
```

### Installazione con funzionalità avanzate (opzionale)

```bash
pip install "dokkument[enhanced]"  # Include rich, click, colorama per UX migliore
```

## 📖 Formato file .dokk

I file `.dokk` utilizzano un formato semplice e leggibile:

```
# Commenti iniziano con #
"Descrizione del link" -> "https://link.com"
"Documentazione API" -> "https://api.example.com/docs"
"Repository GitLab" -> "https://gitlab.com/company/project"
"Dashboard Monitoring" -> "https://grafana.example.com"
```

### Regole formato:
- Una riga per ogni entry
- Formato: `"Descrizione" -> "URL"`
- Righe vuote e commenti (`#`) sono ignorati
- Solo URL HTTP/HTTPS sono supportati

## 🚀 Utilizzo

### Modalità interattiva (default)

```bash
dokkument
```

Scansiona la directory corrente per file `.dokk` e presenta un menu interattivo.

### Modalità lista

```bash
dokkument --list                 # Lista testuale
dokkument --list --format json   # Output JSON
dokkument --list --format markdown  # Output Markdown
```

### Apertura diretta

```bash
dokkument --open-all             # Apre tutti i link
dokkument --open 1 3 5           # Apre i link 1, 3 e 5
```

### Scansione directory specifica

```bash
dokkument --path /docs           # Scansiona directory specifica
dokkument --path /docs --no-recursive  # Non ricorsiva
```

### Statistiche e validazione

```bash
dokkument --stats                # Mostra statistiche
dokkument --validate             # Valida tutti i link
```

## ⚙️ Configurazione

### File di configurazione

dokkument cerca automaticamente file di configurazione in:
- `.dokkument.json` (directory corrente)
- `~/.dokkument.json` (home directory)
- `~/.config/dokkument/config.json` (Linux/macOS)
- `%APPDATA%/dokkument/config.json` (Windows)

### Esempio configurazione

```json
{
  "scanning": {
    "recursive": true,
    "max_depth": 10,
    "excluded_dirs": [".git", "__pycache__", "node_modules"]
  },
  "display": {
    "enable_colors": true,
    "enable_hyperlinks": true,
    "group_by_file": true,
    "confirm_open_all": true
  },
  "browser": {
    "preferred_browser": "firefox",
    "open_delay_seconds": 0.5
  },
  "security": {
    "validate_urls": true,
    "allowed_schemes": ["http", "https"]
  }
}
```

## 🏗️ Architettura

dokkument implementa diversi design pattern per garantire codice pulito e manutenibile:

- **Factory Pattern** - `DokkParserFactory` per gestire diversi tipi di parser
- **Command Pattern** - Sistema di comandi modulare ed estensibile
- **Singleton Pattern** - `ConfigManager` per configurazione globale
- **Strategy Pattern** - Diversi formati di esportazione

## 🤝 Contributi

I contributi sono benvenuti! Per contribuire:

1. Fork del repository
2. Crea branch feature (`git checkout -b feature/nome-feature`)
3. Commit delle modifiche (`git commit -am 'Aggiungi nome-feature'`)
4. Push del branch (`git push origin feature/nome-feature`)
5. Apri una Pull Request

## 📄 Licenza

Distribuito sotto licenza MIT. Vedi `LICENSE` per maggiori informazioni.

## 💬 Supporto

- **Issues**: [GitHub Issues](https://github.com/your-username/dokkument/issues)
- **Documentazione**: [docs.dokkument.com](https://docs.dokkument.com)

---

**Fatto con ❤️ da sviluppatori per sviluppatori**
